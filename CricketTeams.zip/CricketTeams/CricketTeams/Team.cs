﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CricketTeams
{
    public class Team
    {
        public string PlayerName { get; set; }

        public Category PlayerCategory { get; set; }

        public double PlayerCredits { get; set; }

        public int PlayingTeam { get; set; }

    }

    public enum Category
    {
        Keeper = 1,
        Batsmen = 2,
        AllRounder = 3,
        Bowler = 4
    }
   
}
