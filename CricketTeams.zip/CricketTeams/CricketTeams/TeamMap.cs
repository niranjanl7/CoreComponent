﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CsvHelper;
using CsvHelper.Configuration;

namespace CricketTeams
{
    public sealed class TeamMap : CsvClassMap<Team>
    {
        public MyCustomObjectMap()
        {
            // In the name method, you provide the header text - i.e. the header value set in the first line of the CSV file.
            Map(m => m.ID).Name("id");
            Map(m => m.Name).Name("name");
            Map(m => m.Lastname).Name("lastname");
            Map(m => m.Phone).Name("phone");
            Map(m => m.Mail).Name("mail");
            Map(m => m.Website).Name("website");
        }
    }
}
