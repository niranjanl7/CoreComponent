﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;
using static System.Double;
using Excel = Microsoft.Office.Interop.Excel;

namespace CricketTeams
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string csvPath = @"C:\Users\nl12\Desktop\Teams.csv";
            string csvFinalTeams = @"C:\Users\nl12\Desktop\Teams2.csv";
            int maxPlayerPerTeam = 7;
            int maxAllRounder = 3;
            int minAllRounder = 1;
            int minWk = 1;
            int maxBowler = 5;
            int minBowler = 3;
            int maxBatsmen = 5;
            int minBatsmen = 3;
            int maxPlayers = 11;
            int maxCredits = 100;
            double playerCredits;
            int totalNoOfWk, totalNoOfBatsmen, totalNoOfBowler, totalNoOfAr;
            List<Team> teams = new List<Team>();
            Category playerCategory;
            var csv = File.ReadAllText(csvPath);
            csv = csv.Replace('\n', '\r');
            string[] lines = csv.Split(new char[] { '\r' },
                StringSplitOptions.RemoveEmptyEntries);
            int numRows = lines.Length;
            for (int r = 1; r < numRows; r++)
            {
                Team team = new Team();
                string[] lineR = lines[r].Split(',');
                team.PlayerName = lineR[1];
                Enum.TryParse(lineR[2], out playerCategory);
                team.PlayerCategory = playerCategory;
                team.PlayerCredits= Parse(lineR[3]);
                team.PlayingTeam = int.Parse(lineR[4].Split('\"').First());
                teams.Add(team);
            }

            totalNoOfWk = teams.Count(n => n.PlayerCategory == Category.Keeper);
            totalNoOfBatsmen = teams.Count(n => n.PlayerCategory == Category.Batsmen);
            totalNoOfAr = teams.Count(n => n.PlayerCategory == Category.AllRounder);
            totalNoOfBowler = teams.Count(n => n.PlayerCategory == Category.Bowler);
            CombinationSet<string> comb = new CombinationSet<string>(teams.Select(o => o.PlayerName).ToList(), 11);
            //705432
            List<string[]> finalTeamList = new List<string[]>();
            List<Team> filteredTeam = new List<Team>();
            foreach (string[] teamList in comb.ToList())
            {
                filteredTeam = (from first in teamList
                    join second in teams on first equals second.PlayerName
                    select second).ToList();
                double sumLineTotal = 0;
                int team1PlayerCount = 0;
                int team2PlayerCount = 0;
                int batsmenCount = 0;
                int bowlerCount = 0;
                int allRounderCount = 0;
                int wkCount = 0;
                foreach (var od in filteredTeam)
                {
                    sumLineTotal += od.PlayerCredits;
                    if (od.PlayingTeam == 1) team1PlayerCount++;
                    if (od.PlayingTeam == 2) team2PlayerCount++;
                    if (od.PlayerCategory == Category.Batsmen) batsmenCount++;
                    if (od.PlayerCategory == Category.Bowler) bowlerCount++;
                    if (od.PlayerCategory == Category.AllRounder) allRounderCount++;
                    if (od.PlayerCategory == Category.Keeper) wkCount++;
                }

                if (sumLineTotal <= maxCredits && team1PlayerCount <= maxPlayerPerTeam && team2PlayerCount <= maxPlayerPerTeam 
                    && wkCount==minWk)
                {
                    if (/*(bowlerCount==5 && batsmenCount==3 && allRounderCount==2)||(bowlerCount == 4 && batsmenCount == 4 && allRounderCount == 2)
                       ||(bowlerCount == 4 && batsmenCount == 5 && allRounderCount == 1) || (bowlerCount == 4 && batsmenCount == 3 && allRounderCount == 3)
                       || */(bowlerCount == 3 && batsmenCount == 5 && allRounderCount == 2)||(bowlerCount == 3 && batsmenCount == 4 && allRounderCount == 3)
                       /*||(bowlerCount == 5 && batsmenCount == 4 && allRounderCount == 1)*/)
                        finalTeamList.Add(teamList);
                }
            }

            List<string[]> halaTeam = new List<string[]>();
            foreach (string[] ft in finalTeamList)
            {
                //Need to bring this to application layer to select and deselect player. 
                if(!ft.Contains("Denly") && !ft.Contains("Abid") && !ft.Contains("Rashid")
                   && !ft.Contains("Hansain") && ft.Contains("Baristow") && ft.Contains("Root") && ft.Contains("Hafeez") && ft.Contains("Buttler"))
                { 
                    if((ft.Contains("Imad") && !ft.Contains("Hasan") && !ft.Contains("Junaid"))|| (!ft.Contains("Imad") && !ft.Contains("Hasan") && ft.Contains("Junaid"))||
                        (!ft.Contains("Imad") && ft.Contains("Hasan") && !ft.Contains("Junaid")|| (!ft.Contains("Imad") && !ft.Contains("Hasan") && !ft.Contains("Junaid"))
                       ))
                    { 
                        halaTeam.Add(ft);
                       SaveArrayinExcel(ft, csvFinalTeams);
                    }
                }
            }
            halaTeam.Count();
        }

        private void SaveArrayinExcel(string[] halaTeam, string csvFinalTeams)
        {
            var result = string.Join(",", halaTeam);
            File.AppendAllText(csvFinalTeams,result+Environment.NewLine);
        }
    }
    }
